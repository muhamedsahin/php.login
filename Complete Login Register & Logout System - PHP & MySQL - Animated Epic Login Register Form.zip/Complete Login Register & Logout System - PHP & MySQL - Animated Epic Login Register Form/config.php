<?php

$hostname = "localhost";
$username = "root";
$password = "";
$database = "login_register_youtube";

$conn = mysqli_connect($hostname, $username, $password, $database) or die("Database connection failed");

?>